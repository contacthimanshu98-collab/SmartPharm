from flask import Flask, render_template, request, redirect, url_for
import os
from ocr_engine import extract_text_from_image
from medicine_engine import get_medicine_recommendations

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'

if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'report' not in request.files:
        return redirect(url_for('index'))

    file = request.files['report']
    if file.filename == '':
        return redirect(url_for('index'))

    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filepath)

    # OCR + Medicine recommendation
    extracted_text = extract_text_from_image(filepath)
    medicines = get_medicine_recommendations(extracted_text)

    return render_template('result.html', text=extracted_text, medicines=medicines)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)