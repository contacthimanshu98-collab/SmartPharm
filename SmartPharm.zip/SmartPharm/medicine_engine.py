import requests
from bs4 import BeautifulSoup

def get_medicine_recommendations(text):
    query = text.replace("\n", " ")
    url = f"https://pubmed.ncbi.nlm.nih.gov/?term={query}"
    response = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'})

    soup = BeautifulSoup(response.text, 'html.parser')
    results = soup.find_all('a', class_='docsum-title')

    meds = []
    for r in results[:5]:
        title = r.get_text(strip=True)
        link = "https://pubmed.ncbi.nlm.nih.gov" + r['href']
        meds.append({"title": title, "link": link})

    if not meds:
        meds.append({"title": "No direct match found. Try more specific symptoms.", "link": "#"})

    return meds