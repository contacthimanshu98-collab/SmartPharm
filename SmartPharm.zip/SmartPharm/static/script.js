document.querySelector('input[type="file"]').addEventListener('change', (e) => {
    const fileName = e.target.files[0].name;
    alert(`Selected: ${fileName}`);
});